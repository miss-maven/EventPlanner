/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventrental;

import javax.swing.JOptionPane;

/**
 *
 * @author Maven
 */
public class Chair 
{
    int amountChair;
   
   public int getChairAmount()
   {
       return amountChair;
   }
   
   public void setChairAmount(int chairAmount)
   {
       amountChair = chairAmount;
   }
    
}
