/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventrental;

import javax.swing.JOptionPane;

/**
 *
 * @author Maven
 */
public class Table 
{
   int amountTable;
   
   public int getTableAmount()
   {
       return amountTable;
   }
   
   public void setTableAmount(int tableAmount)
   {
       amountTable = tableAmount;
   }
}
